# dxxxleo — NightTrace

Fictional horror / doxx-style visual website.

Shown identity:
- Discord: x.o Leoosdkkkkk
- SV: dxx.2101
- Allies: trapcute, trapnet, trapshit, T2S, threat2Society, X.o FORTUNE, Brutal tribe

Safety:
This site is only a horror-themed visual. It does not retrieve IP addresses, Discord information,
locations, camera data, or other personal information.

FILES:
- index.html
- style.css
- script.js

PUBLISH WITH GITHUB PAGES:
1. Create/sign in to a GitHub account.
2. Create a NEW public repository, e.g. `dxxxleo`.
3. Upload index.html, style.css, and script.js to the repository root.
4. Open Settings -> Pages.
5. Under Build and deployment, choose `Deploy from a branch`.
6. Select Branch: `main`, Folder: `/ (root)`, then Save.
7. Wait a few minutes.
8. GitHub will show the public Pages address in the Pages section.

Your public address will follow this pattern:
https://YOUR-GITHUB-USERNAME.github.io/dxxxleo/

Do not put real private information in the site.
