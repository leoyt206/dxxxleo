const discordName = "x.o Leoosdkkkkk";
document.getElementById("discordName").textContent = discordName;

const clock = document.getElementById("clock");
function updateClock() {
  const d = new Date();
  clock.textContent = d.toLocaleTimeString([], {hour12:false});
}
setInterval(updateClock, 1000);
updateClock();

const lines = [
  "[00:00:01] initializing trace node...",
  "[00:00:02] searching public signal...",
  "[00:00:03] discord identifier detected.",
  "[00:00:04] cross-reference: ████████████",
  "[00:00:05] proximity estimate: UNKNOWN",
  "[00:00:06] camera status: █████",
  "[00:00:07] observer detected.",
  "[00:00:08] <span class='danger'>STOP LOOKING.</span>",
];

const log = document.getElementById("log");
lines.forEach((line, i) => {
  setTimeout(() => {
    const div = document.createElement("div");
    div.innerHTML = line;
    log.appendChild(div);
  }, i * 550);
});

const message = document.getElementById("message");
const text = "I KNOW YOU ARE STILL HERE.";
let i = 0;
function typeMessage() {
  if (i < text.length) {
    message.textContent += text[i++];
    setTimeout(typeMessage, 70);
  }
}
setTimeout(typeMessage, 4700);

const modal = document.getElementById("modal");
const modalText = document.getElementById("modalText");

document.getElementById("panic").addEventListener("click", () => {
  modal.classList.add("show");
  modalText.textContent = `${discordName}... the archive was never meant to be opened.`;
  document.body.style.animation = "shake .08s infinite";
});

document.getElementById("close").addEventListener("click", () => {
  modal.classList.remove("show");
  document.body.style.animation = "";
});

document.addEventListener("keydown", e => {
  if (e.key === "Escape") modal.classList.remove("show");
});


let n = 13;
const countdown = document.getElementById("countdown");
const timer = setInterval(() => {
  n--;
  countdown.textContent = `SIGNAL DECAY: ${String(Math.max(n,0)).padStart(2,"0")}`;
  if (n <= 0) {
    n = 13;
    countdown.textContent = "SIGNAL DECAY: 13";
  }
}, 1000);

document.getElementById("panic").addEventListener("click", () => {
  document.body.classList.add("shake");
  setTimeout(() => document.body.classList.remove("shake"), 700);
});
